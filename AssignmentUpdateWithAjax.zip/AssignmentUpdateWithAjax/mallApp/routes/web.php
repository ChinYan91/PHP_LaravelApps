<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//tenant
Route::resource('/tenant', 'TenantController');
Route::get('/tenant', 'TenantController@index')->name('tenant.index');
Route::get('/tenant/{id}','TenantController@show')->name('tenant.show');
Route::get('/tenant/create', 'TenantController@create')->name('tenant.create');
Route::get('/tenant/{id}/edit','TenantController@edit')->name('tenant.edit');
Route::get('tenant/delete/{tenant}',['as' => 'tenant.delete', 'uses' => 'TenantController@destroy']);

//lot
Route::resource('/lot', 'LotController');
Route::get('/lot', 'LotController@index')->name('lot.index');
Route::get('/lot/{id}','LotController@show')->name('lot.show');
Route::get('/lot/create', 'LotController@create')->name('lot.create');
Route::get('/lot/{id}/edit','LotController@edit')->name('lot.edit');
Route::get('lot/delete/{lot}',['as' => 'lot.delete', 'uses' => 'LotController@destroy']);

//front end: AJAX Live Search
Route::get('/live_search','LiveSearch@index');
Route::get('/live_search/action','LiveSearch@action')->name('live_search.action');


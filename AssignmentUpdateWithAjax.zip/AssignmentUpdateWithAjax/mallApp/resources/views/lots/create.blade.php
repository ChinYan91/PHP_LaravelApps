<?php
use App\Dictionary;
?>
<head><h1>Lot For Rent at Traveller Mall</h1></head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a class="active" href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav></br></br>
@extends('layouts.app')

@section('content')

<!-- Bootstrap Boilerplate... -->

<div class="panel-body">
<!-- New lot Form -->
{!! Form::model($lot, [
'route' => ['lot.store'],
'class' => 'form-horizontal'
]) !!}

<!-- Lot Number-->
<div class="form-group_row">
{!! Form::label('lot-lot_no', 'Lot No. :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('lot_no', null, [
'id' => 'lot-lot_no',
'class' => 'form-control',
'maxlength' => 5,
]) !!}
</div>
</div></br>

<!-- store_name -->
<div class="form-group_row">
{!! Form::label('lot-store_name', 'Store Name :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('store_name', null, [
'id' => 'lot-store_name',
'class' => 'form-control',
'maxlength' => 100,
]) !!}
</div>
</div></br>

<!-- department -->
<div class="form-group_row">
	{!! Form::label('lot-department', 'Department :', [
	'class' => 'control-label col-sm-3',
	]) !!}
<div class="col-sm-9">
	{!! Form::select('department', Dictionary::$departments, null, [
	'class' => 'form-control',
	'placeholder' => '- Select department -',
	]) !!}
</div>
</div></br>

<!-- level -->
<div class="form-group_row">
{!! Form::label('lot-level', 'Level :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::select('level', Dictionary::$levels, null, [
'id' => 'lot-level',
'class' => 'form-control',
'placeholder' => '- Select level -',
]) !!}
</div>
</div></br>

<!-- tenant_id -->
<div class="form-group_row">
{!! Form::label('lot-tenant_id', 'Tenant ID :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('tenant_id', null, [
'id' => 'lot-tenant_id',
'class' => 'form-control',
'maxlength' => 5,
]) !!}
</div>
</div></br>

<!-- Submit Button -->
<div class="form-group_row">
<div class="col-sm-offset-3 col-sm-6">
	{!! Form::button('Rent', [
	'type' => 'submit',
	'class' => 'btn btn-primary',
	]) !!}
</div>
</div></br>
{!! Form::close() !!}
</div>

@endsection
<?php

	use App\Dictionary;
	use App\tenant;

?>
<head><h1>Lot Rental Detail :</h1></head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a class="active" href="/lot">View Lot Detail</a></li>
    </ul>
</nav>
@extends('layouts.app')

@section('content')
<!-- Bootstrap Boilerplate... -->
<div class="panel-body">
@if (count($lots) > 0)
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>No.</th>
<th>Lot No.</th>
<th>Store Name</th>
<th>Department</th>
<th>Level</th>
<th>Tenant ID</th>
<th>Action</th>
</tr>
</thead>

<!-- Table Body -->
<tbody>
@foreach ($lots as $i => $lot)
<tr>
<td class="table-text">
<div>{{ $i+1 }}</div>
</td>
<td class="table-text">
<div>
{!! link_to_route(
'lot.show',
$title = $lot->lot_no,
$parameters = [
'id' => $lot->id,
]
) !!}
</div>
</td>

<td class="table-text">
<div>{{ $lot->store_name }}</div>
</td>

<td class="table-text">
<div>{{ Dictionary::$departments[$lot->department] }}</div>
</td>

<td class="table-text">
<div>{{ Dictionary::$levels[$lot->level] }}</div>
</td>

<td class="table-text">
<div>{{ $lot->tenant_id }}</div>
</td>

<td class="table-text">
<div>
{!! link_to_route(
'lot.edit',
$title = 'Edit',
$parameters = [
'id' => $lot->id,
]
) !!}
<!--
{!!
 Form::open(['method' => 'DELETE', 'route' => ['lot.destroy', $lot->id]]) 
!!}
{!!
	Form::submit('Delete')
!!}
-->
<a href="{{ route('lot.delete', $lot->id) }}">Delete</a>
</div>
</td>
</tr>
@endforeach
</tbody>
</table>
<br/>
<footer>
<a href = '/lot/create'>Add New</a>
</footer> 
@else
<div>
No records found
</div>
@endif
</div>
@endsection
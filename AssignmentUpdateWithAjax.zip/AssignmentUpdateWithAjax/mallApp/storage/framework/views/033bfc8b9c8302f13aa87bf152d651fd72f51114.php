<?php

	use App\Dictionary;

?>
<head><h1>Tenants' Detail</h1><head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a class="active" href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav>


<?php $__env->startSection('content'); ?>
<!-- Bootstrap Boilerplate... -->
<div class="panel-body">
<?php if(count($tenants) > 0): ?>
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>No.</th>
<th>Tenant ID.</th>
<th>Tenant Name</th>
<th>Tenant Contact</th>
<th>Tenant Email</th>
<th>Tenant Address</th>
<th>Actions</th>
</tr>
</thead>

<!-- Table Body -->
<tbody>
<?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td class="table-text">
<div><?php echo e($i+1); ?></div>
</td>
<td class="table-text">
<div>
<?php echo link_to_route(
'tenant.show',
$title = $tenant->tenant_id,
$parameters = [
'id' => $tenant->id,
]
); ?>

</div>
</td>
<td class="table-text">
<div><?php echo e($tenant->tenant_name); ?></div>
</td>
<td class="table-text">
<div><?php echo e($tenant->tenant_contact); ?></div>
</td>
<td class="table-text">
<div><?php echo e($tenant->tenant_email); ?></div>
</td>
<td class="table-text">
<div><?php echo e($tenant->tenant_address); ?></div>
</td>
<td class="table-text">
<div>
<?php echo link_to_route(
'tenant.edit',
$title = 'Edit',
$parameters = [
'id' => $tenant->id,
]
); ?>

|
<!--<?php echo Form::open(['method' => 'DELETE', 'route' => ['tenant.destroy', $tenant->id]]); ?>

<?php echo Form::submit('Delete'); ?>

-->
<a href="<?php echo e(route('tenant.delete', $tenant->id)); ?>">Delete</a>
</div>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<br/>
<footer>
<a href = '/tenant/create'>Add New</a> 
</footer>
<?php else: ?>
<div>
No records found
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
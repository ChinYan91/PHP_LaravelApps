<?php

use App\Dictionary;

?>
<head><h1>Lot's Information</h1></head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav>


<?php $__env->startSection('content'); ?>

<!-- Bootstrap Boilerplate... -->

<div class="panel-body">
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>Attribute</th>
<th>Value</th>
</tr>
</thead>
<!-- Table Body -->
<tbody>
<tr>
<td>Lot No.</td>
<td><?php echo e($lot->lot_no); ?></td>
</tr>
<tr>
<td>Store Name</td>
<td><?php echo e($lot->store_name); ?></td>
</tr>
<tr>
<td>Department</td>
<td><?php echo e(Dictionary::$departments [$lot->department]); ?></td>
</tr>
<tr>
<td>Level</td>
<td><?php echo e(Dictionary::$levels[$lot->level]); ?></td>
</tr>
<tr>
<td>Tenant ID.</td>
<td><?php echo nl2br($lot->tenant_id); ?></td>
</tr>
</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
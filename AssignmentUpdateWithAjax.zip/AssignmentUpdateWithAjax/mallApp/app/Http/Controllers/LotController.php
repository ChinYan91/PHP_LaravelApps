<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Lot;


class LotController extends Controller
{
    //
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		$lots = Lot::orderBy('store_name', 'asc')->get();
		return view('lots.index', ['lots' => $lots,]);
    }

    public function level()
    {   
        $lots = Lot::orderBy('level','asc')->get();
        return view('lots.level', ['lots' => $lots]);
    }

    public function department()
    {
        $lots = Lot::orderBy('department', 'asc')->get();
		return view('lots.department', ['lots' => $lots,]);
    }

    public function storeName()
    {
        $lots = Lot::orderBy('store_name', 'asc')->get();
		return view('lots.storeName', ['lots' => $lots,]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
		$lot = new Lot();

		return view('lots.create', [
		'lot' => $lot,
		]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
		$lot = new Lot;
		$lot->fill($request->all());
		$lot->save();
	
		return redirect()->route('lot.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
		$lot = Lot::find($id);
		if(!$lot) throw new ModelNotFoundException;		
		return view('lots.show', [
		'lot' => $lot,
		]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
		$lot = Lot::find($id);
		if(!$lot) throw new ModelNotFoundException;
		return view('lots.edit', [
		'lot' => $lot,
		]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
		$lot = Lot::find($id);
		if(!$lot) throw new ModelNotFoundException;
		$lot->fill($request->all());
		$lot->save();
		return redirect()->route('lot.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		$lot = Lot::find($id);
        $lot->delete(); 
        return redirect()->route('lot.index')
                        ->with('success','lot deleted successfully');

    }
}

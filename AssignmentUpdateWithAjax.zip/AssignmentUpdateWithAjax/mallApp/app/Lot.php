<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lot extends Model
{
    //
    protected $fillable = [
		'lot_no',
		'store_name',
        'department',
        'level',
		'tenant_id',
		
	];
}
